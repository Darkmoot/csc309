window.onload = function() {
    
    /* Global variables */
    
    // Initiate the timer to 60, game level to 0, score to 200.
    window.ingame_time = 60;
    window.game_level = 0;
    window.game_score = 200;
    
    /* Global Methods */

    
// Store and retrieve high score to/from local storage.
if (typeof(Storage) !== "undefined") {
    // Store
    // create localStorage name/value pair, name="score", value="00:00"
    // note: name-value pairs always stored as strings
    localStorage.setItem("score", "00:00");
    // Retrieve value of "score" and insert it into element with id="high_score_value"
    document.getElementById("high_score_value").innerHTML = localStorage.getItem("score");
} else {
    // no web storage support
}

    // By default, display the start page until the start button is clicked.
    document.getElementById("start_page").style.visibility = "visible";
    
    // Hide the level one and level two pages.
    document.getElementById("level_one_page").style.display = "none";
    document.getElementById("level_two_page").style.display = "none";
    
    // Initialize the canvas context.
    var c = document.getElementById("level_one_canvas");
    window.ctx = c.getContext("2d");
}


function start() {
    document.getElementById("start_page").style.display = "none";
    document.getElementById("level_one_page").style.display = "block";
    game_level = 1;
    ingame_time = 60;
    // Call the drawCanvas function every second (every 1000 milliseconds)
    // in order to decrement the game timer.
    setInterval(drawCanvas, 1000);
}

/*
 * Draw the next level.
 *
 */
function nextLevel() {
    // drawLevelTwo();
    game_level = 2;
}

/*
 * Draw the general parts of this game canvas.
 *
 */
function drawCanvas() {
    ctx.clearRect(0, 0, 1000, 640);
    ctx.fillStyle = "#000000";
    ctx.fillRect(0, 40, 1000, 640);
    ctx.fillStyle = "#FFFFFF";
    ctx.font = "1em Montserrat";
    ctx.textAlign = "center";
    ctx.fillText("Level " + game_level, 50, 30);
    ctx.fillText("Score: " + game_score, 300, 30);
    ctx.fillText("Pause", 700, 30);
    timer();
    ctx.fillText(window.ingame_time, 900, 30);
}

/* Potentially necessary functions.
function drawLevelOne() {
}

function drawLevelTwo() {
}

function drawPauseOverlay() {
}

function pause() {
    
}

function transitionLevel() {
}
*/

/*
 * Decrement in-game time by 1.
 *
 */
function timer() {
    if(window.ingame_time > 0)  {
    window.ingame_time = window.ingame_time - 1;
    } else {
        // When the transiton level screen is implemented, call that instead of
        // nextLevel() when the timer hits 0.
        nextLevel();
    }
}