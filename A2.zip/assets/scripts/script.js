window.onload = function() {
    // Store and retrieve high score to/from local storage.
if (typeof(Storage) !== "undefined") {
    // Store
    // create localStorage name/value pair, name="high_score", value="Smith"
    // note: name-value pairs always stored as strings
    localStorage.setItem("score", "00:00");
    // Retrieve
    // Retrieve value of "high_score_value" and insert it into element with id="high_score_display"
    document.getElementById("high_score_value").innerHTML = localStorage.getItem("score");
} else {
    // no web storage support
}
// by default, display the start page until the start button is clicked
document.getElementById("start_page").style.visibility = "visible";
// hide the level one and level two pages
document.getElementById("level_one_page").style.display = "none";
document.getElementById("level_two_page").style.display = "none";
var c = document.getElementById("level_one_canvas");
window.ctx = c.getContext("2d");
draw();    
}


function start() {
document.getElementById("start_page").style.display = "none";
document.getElementById("level_one_page").style.display = "block";
    
}

function draw() {
    ctx.fillStyle = "#000000";
    ctx.fillRect(0, 0, 1000, 640);
}